/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app4Bim;

import java.util.Scanner;
import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author 05135096159
 */
public class Questao1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        String[] nome=new String[10];
        for (int i = 0; i < nome.length; i++) {
          nome[i]=in.nextLine();  
        }
        Arrays.sort(nome);
        System.out.println(""+nome[5]);
        //for (int i = 0; i < nome.length; i++) {
          //  System.out.println(nome[i]);
        }
    }
    

